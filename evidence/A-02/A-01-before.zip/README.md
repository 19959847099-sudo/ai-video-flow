# A-01 角色连续生产主链 V0

本地桌面工具：角色卡 → Look / Reference → Shot → Generation Task → Dummy Adapter。

## 安装与启动

使用带 Tkinter 的 Python 3.11+（本机已验证 Python 3.13.3）。在项目目录运行：

```powershell
python -m pip install -r requirements.txt
python -m app.gui
```

也可以双击 `start.cmd`。当前电脑所需运行依赖已经存在。应用无需网络。

## 操作

1. 角色卡页点击“新建角色”，填写名称、核心身份描述，保存。测试角色勾选“测试 / 示例数据”。
2. “添加图片…”打开文件选择器，支持 PNG / JPEG / WebP，可多选。图片会复制到项目资产目录并按内容去重。
3. 在 Reference 列表选图可预览；“设为 / 取消身份图”指定所有 Look 共用的身份图。
4. 填写 Look 名称、状态、外观，在下方列表点击选择专用图，再点“保存 Look 和角色”。点“新建 Look”添加另一套状态。下拉选择已有 Look 可编辑。
5. Shot 页点击“新建 Shot”，选择角色和 Look，填写镜头需求及生成描述，保存。另建 Shot 可复用同一角色并换 Look。
6. “生成任务（Dummy 验证）”保存当前 Shot，并读取角色资产形成任务；结果区与底部状态栏显示成功。它不会调用 API，也不会生成视频。
7. 退出前保存编辑。重新打开后从左侧列表选择角色 / Shot 查看，Look 下拉框可切换状态。

Reference 的“删除”会移除角色及 Look 关联；底层媒体保留，避免破坏已生成任务的快照。未关联到身份或当前 Look 的图片不会进入该任务的有效参考图列表。

## 数据位置与迁移

```text
app/                    GUI、数据模型、文件存储、Adapter
schemas/                从 Pydantic 模型导出的 JSON Schema
data/characters/        一个角色一个 JSON，含 Look 与 Reference 关系
data/shots/             一个 Shot 一个 JSON，仅使用角色 / Look ID 引用
data/assets/            内容哈希命名的图片，JSON 保存相对 data/ 的路径
data/tasks/<task-id>/   task.json 快照 + dummy_request.json
examples/               明确标注的测试图片
tests/                  核心链路测试
evidence/               验证截图、操作记录、冻结文件校验与回执
```

备份 / 迁移时一起复制整个 `data/`。不用保留导入图片的原始位置。Character JSON 与其关联媒体可以脱离 GUI 被其他程序读取；不应只复制 JSON 而遗漏 assets。

可用 `python -m app.gui --data-dir <目录>` 打开独立数据目录。正常使用无需输入路径。请一次只打开一个应用窗口操作同一数据目录；V0 没有并发编辑合并。

## 当前边界

没有商业 API、真实视频生成、角色一致性模型验证、剪辑、自动审美判断、数据库、云端部署或完整 Attempt Ledger。任务是数据交接快照，不是真实生成 Attempt。示例图片是测试色卡，不是正式角色设计。

ProviderAdapter 仅定义 `prepare(task, asset_root)` 边界。未来真实 Adapter 在外围解析图片、转换请求、调用程序化 API；Character / Shot 无 Provider 字段。当前 Dummy 只验证本地资产并写出模拟请求。

## 验证与复用

```powershell
python -m unittest discover -s tests -v
```

复用 Python 标准库 Tkinter / pathlib / JSON，以及本机已有 Pillow、Pydantic；仅自建生产数据关系与交接逻辑。未引入 Web 服务或大型框架。Pillow 用于图片校验和预览，Pydantic 用于输入校验和 Schema 导出。

`tools/drive_gui.py` 为 Windows 桌面验收辅助，使用隔离在 `.test-tools/` 的 pywinauto，不是运行依赖。`evidence/actions-*.json` 记录本次屏幕坐标操作；坐标依赖验收时窗口尺寸，不是可跨设备直接运行的通用自动测试。GUI 操作由执行者通过工具驱动并检查截图，用户本人验收尚需自行进行。
