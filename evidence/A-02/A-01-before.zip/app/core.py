"""Portable production records. All media paths are relative to the data root."""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Literal, Protocol
from uuid import uuid4
from datetime import datetime, timezone

from PIL import Image
from pydantic import BaseModel, ConfigDict, Field, model_validator


def new_id():
    return uuid4().hex


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Reference(Record):
    id: str = Field(default_factory=new_id)
    name: str = Field(min_length=1)
    path: str
    sha256: str


class Look(Record):
    id: str = Field(default_factory=new_id)
    name: str = Field(min_length=1)
    description: str = ""
    appearance: str = ""
    reference_ids: list[str] = Field(default_factory=list)


class Character(Record):
    schema_version: Literal["0.1"] = "0.1"
    id: str = Field(default_factory=new_id)
    name: str = Field(min_length=1)
    description: str = ""
    identity: str = Field(min_length=1)
    is_example: bool = False
    references: list[Reference] = Field(default_factory=list)
    identity_reference_ids: list[str] = Field(default_factory=list)
    looks: list[Look] = Field(default_factory=list)

    @model_validator(mode="after")
    def relations(self):
        ids = [r.id for r in self.references]
        if len(set(ids)) != len(ids) or len({x.id for x in self.looks}) != len(self.looks):
            raise ValueError("Reference / Look ID 重复")
        for refs in [self.identity_reference_ids] + [x.reference_ids for x in self.looks]:
            if len(set(refs)) != len(refs) or not set(refs) <= set(ids):
                raise ValueError("Reference 引用无效或重复")
        return self


class Shot(Record):
    schema_version: Literal["0.1"] = "0.1"
    id: str = Field(default_factory=new_id)
    description: str = Field(min_length=1)
    character_id: str
    look_id: str
    requirements: str = Field(min_length=1)
    generation_description: str = Field(min_length=1)
    is_example: bool = False


class GenerationTask(Record):
    schema_version: Literal["0.1"] = "0.1"
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    kind: Literal["video"] = "video"
    is_example: bool
    shot: Shot
    character: Character
    look: Look
    references: list[Reference]
    prompt_source: dict[str, str]


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + new_id() + ".tmp")
    try:
        with temp.open("w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


class Store:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, relative: str):
        result = (self.root / relative).resolve()
        if not result.is_relative_to(self.root):
            raise ValueError("资产路径必须位于数据目录内")
        return result

    def record_path(self, kind, identifier):
        if not re.fullmatch(r"[a-f0-9]{32}", identifier):
            raise ValueError("记录 ID 无效")
        return self.path(f"{kind}/{identifier}.json")

    def characters(self):
        return [Character.model_validate_json(p.read_text(encoding="utf-8"))
                for p in sorted(self.path("characters").glob("*.json"))]

    def shots(self):
        return [Shot.model_validate_json(p.read_text(encoding="utf-8"))
                for p in sorted(self.path("shots").glob("*.json"))]

    def character(self, identifier):
        return Character.model_validate_json(self.record_path("characters", identifier).read_text(encoding="utf-8"))

    def save_character(self, character):
        character = Character.model_validate(character.model_dump())
        for ref in character.references:
            if not self.path(ref.path).is_file():
                raise ValueError(f"Reference 文件缺失：{ref.name}")
        write_json(self.record_path("characters", character.id), character.model_dump())

    def save_shot(self, shot):
        shot = Shot.model_validate(shot.model_dump())
        char = self.character(shot.character_id)
        if not any(x.id == shot.look_id for x in char.looks):
            raise ValueError("Look 不属于所选角色")
        write_json(self.record_path("shots", shot.id), shot.model_dump())

    def import_reference(self, filename):
        source = Path(filename)
        if source.stat().st_size > 30 * 1024 * 1024:
            raise ValueError("图片不能超过 30 MB")
        with Image.open(source) as im:
            fmt = im.format
            im.verify()
        suffix = {"PNG": ".png", "JPEG": ".jpg", "WEBP": ".webp"}.get(fmt)
        if not suffix:
            raise ValueError("请选择 PNG、JPEG 或 WebP 图片")
        content = source.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        relative = f"assets/{digest}{suffix}"
        destination = self.path(relative)
        destination.parent.mkdir(exist_ok=True)
        if not destination.exists():
            destination.write_bytes(content)
        return Reference(name=source.name, path=relative, sha256=digest)

    def task(self, shot_id):
        shot = Shot.model_validate_json(self.record_path("shots", shot_id).read_text(encoding="utf-8"))
        char = self.character(shot.character_id)
        look = next((x for x in char.looks if x.id == shot.look_id), None)
        if look is None:
            raise ValueError("Shot 所引用的 Look 不存在")
        selected = set(char.identity_reference_ids + look.reference_ids)
        refs = [r for r in char.references if r.id in selected]
        if not refs:
            raise ValueError("请为角色勾选身份参考图，或为当前 Look 勾选参考图")
        for ref in refs:
            if hashlib.sha256(self.path(ref.path).read_bytes()).hexdigest() != ref.sha256:
                raise ValueError(f"Reference 内容已改变：{ref.name}")
        return GenerationTask(is_example=char.is_example or shot.is_example,
            shot=shot, character=char, look=look, references=refs,
            prompt_source={"identity": char.identity, "character_description": char.description,
                "look": look.description, "appearance": look.appearance,
                "shot": shot.description, "requirements": shot.requirements,
                "generation_description": shot.generation_description})

    def generate(self, shot_id, adapter: ProviderAdapter):
        task = self.task(shot_id)
        request = adapter.prepare(task, self.root)
        folder = self.path(f"tasks/{task.id}")
        write_json(folder / "task.json", task.model_dump())
        write_json(folder / "dummy_request.json", request)
        return task, folder


class ProviderAdapter(Protocol):
    """Translate neutral tasks at the edge; real adapters must use programmatic APIs."""
    def prepare(self, task: GenerationTask, asset_root: Path) -> dict: ...


class DummyProviderAdapter:
    def prepare(self, task: GenerationTask, asset_root: Path) -> dict:
        for ref in task.references:
            path = (asset_root / ref.path).resolve()
            if not path.is_relative_to(asset_root.resolve()) or not path.is_file():
                raise ValueError("Adapter 无法读取 Reference")
        return {"provider": "dummy", "simulation_only": True, "api_called": False,
            "task_id": task.id, "model": "dummy-video-v0",
            "input": {"text": "\n".join(task.prompt_source.values()),
                      "images": [{"asset_path": r.path, "sha256": r.sha256} for r in task.references]}}
