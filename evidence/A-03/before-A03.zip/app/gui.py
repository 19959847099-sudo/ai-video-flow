from __future__ import annotations

import argparse
import json
import os
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageOps, ImageTk

from .core import Character, Look, Shot, Store, DummyProviderAdapter
from .production import MockProviderAdapter
from .scene_gui import SceneEditor
from .review_gui import ReviewPanel


class App(tk.Tk):
    def __init__(self, data_root):
        super().__init__()
        self.title("AI 视频工作流 · A-02 角色 + 场景 + Mock 生产")
        self.geometry("1160x860")
        self.minsize(1000, 820)
        self.store = Store(data_root)
        self.provider = MockProviderAdapter(self.store)
        self.worker = ThreadPoolExecutor(max_workers=1)
        self.pending_work = None
        self.players = []
        self.closing = False
        self.char = None
        self.shot = None
        self.look_id = None
        self.dirty = False
        self.status = tk.StringVar(value="本地文件 · 零 API 费用 · Mock 占位视频 · 最终 Take 由你决定")
        self.protocol("WM_DELETE_WINDOW", self.close)
        ttk.Label(self, textvariable=self.status, wraplength=1100).pack(side="bottom", fill="x", padx=14, pady=8)
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=10)
        self.ctab = ttk.Frame(self.tabs, padding=12)
        self.stab = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.ctab, text="角色卡")
        self.scene_editor = SceneEditor(self.tabs, self)
        self.tabs.add(self.scene_editor, text="场景")
        self.tabs.add(self.stab, text="Shot / 生成任务")
        self.build_char()
        self.build_shot()
        self.review_panel = ReviewPanel(self.tabs, self)
        self.tabs.add(self.review_panel, text="结果 / Review")
        self.active_tab = 0
        self.tabs.bind("<<NotebookTabChanged>>", self.tab_changed)
        self.bind_all("<KeyRelease>", self.mark_dirty, add=True)
        self.refresh()
        self.after(600, self.poll_jobs)

    def poll_jobs(self):
        if self.closing: return
        try:
            if self.pending_work is not None:
                if self.pending_work.done():
                    job = self.pending_work.result()
                    self.pending_work = None
                    self.status.set(f"Mock Take {job.take_number} · {job.status}" + (f" · {job.error}" if job.error else ""))
                    self.review_panel.refresh()
            else:
                jobs = [j for j in self.provider.executions() if j.status in ("pending", "processing")]
                if jobs: self.pending_work = self.worker.submit(self.provider.poll, jobs[0].id)
        except Exception as exc:
            self.pending_work = None
            self.status.set("生成状态读取失败：" + str(exc))
        self.after(600, self.poll_jobs)

    def tab_changed(self, event=None):
        current = self.tabs.index("current")
        if current == self.active_tab: return
        if self.dirty:
            messagebox.showinfo("请先保存", "请先保存当前页的编辑，再切换页面。", parent=self)
            self.tabs.select(self.active_tab)
            return
        self.active_tab = current
        if self.tabs.select() == str(self.review_panel): self.review_panel.refresh()

    def mark_dirty(self, event=None):
        if event is None or isinstance(event.widget, (ttk.Entry, tk.Text)):
            self.dirty = True

    def guard(self, action):
        try:
            action()
        except Exception as exc:
            self.status.set("操作失败：" + str(exc))
            messagebox.showerror("操作未完成", str(exc), parent=self)

    def button(self, parent, text, command):
        result = ttk.Button(parent, text=text, command=lambda: self.guard(command))
        result.pack(side="left", padx=3, pady=4)
        return result

    def field(self, parent, label):
        ttk.Label(parent, text=label).pack(anchor="w", pady=(5, 1))
        var = tk.StringVar()
        ttk.Entry(parent, textvariable=var).pack(fill="x")
        return var

    def confirm_discard(self):
        return not self.dirty or messagebox.askyesno("尚未保存", "放弃未保存的编辑并继续？", parent=self)

    def close(self):
        if self.confirm_discard():
            self.closing = True
            for process in self.players:
                if process.poll() is None: process.terminate()
            self.worker.shutdown(wait=True)
            self.destroy()

    def build_char(self):
        left = ttk.Frame(self.ctab, width=200)
        left.pack(side="left", fill="y", padx=(0, 14))
        ttk.Label(left, text="角色列表").pack(anchor="w")
        self.char_list = tk.Listbox(left, width=24, exportselection=False)
        self.char_list.pack(fill="both", expand=True)
        self.char_list.bind("<<ListboxSelect>>", lambda e: self.guard(self.select_char))
        self.button(left, "新建角色", self.new_char)
        right = ttk.Frame(self.ctab)
        right.pack(side="left", fill="both", expand=True)
        self.cname = self.field(right, "角色名称 *")
        self.cdesc = self.field(right, "基本描述")
        self.cidentity = self.field(right, "核心身份描述 *（保持稳定的特征）")
        self.cexample = tk.BooleanVar()
        ttk.Checkbutton(right, text="测试 / 示例数据", variable=self.cexample,
                        command=self.mark_dirty).pack(anchor="w", pady=4)
        refs = ttk.LabelFrame(right, text="Reference · 选中可预览；身份图会用于每个 Look", padding=8)
        refs.pack(fill="x", pady=6)
        self.ref_list = tk.Listbox(refs, height=4, exportselection=False)
        self.ref_list.pack(side="left", fill="x", expand=True)
        self.ref_list.bind("<<ListboxSelect>>", lambda e: self.guard(self.preview))
        self.preview_label = ttk.Label(refs, text="图片预览", width=20)
        self.preview_label.pack(side="right", padx=8)
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        self.button(bar, "添加图片…", self.add_ref)
        self.button(bar, "删除所选 Reference", self.remove_ref)
        self.button(bar, "设为 / 取消身份图", self.toggle_identity)
        looks = ttk.LabelFrame(right, text="Look / State · 名称与外观可独立编辑", padding=8)
        looks.pack(fill="both", expand=True, pady=6)
        self.look_choice = ttk.Combobox(looks, state="readonly")
        self.look_choice.pack(fill="x")
        self.look_choice.bind("<<ComboboxSelected>>", lambda e: self.guard(self.select_look))
        self.lname = self.field(looks, "Look 名称 *")
        self.ldesc = self.field(looks, "状态描述")
        self.lappearance = self.field(looks, "外观补充（服装、妆容等）")
        ttk.Label(looks, text="当前 Look 专用图（可多选；不会自动使用其他 Look 的图）").pack(anchor="w", pady=(6, 0))
        self.look_refs = tk.Listbox(looks, height=3, selectmode="multiple", exportselection=False)
        self.look_refs.pack(fill="x")
        self.look_refs.bind("<<ListboxSelect>>", lambda e: self.mark_dirty())
        lb = ttk.Frame(looks)
        lb.pack(fill="x")
        self.button(lb, "新建 Look", self.new_look)
        self.button(lb, "保存 Look 和角色", self.save_look)
        self.button(right, "保存角色", self.save_char)

    def build_shot(self):
        left = ttk.Frame(self.stab)
        left.pack(side="left", fill="y", padx=(0, 14))
        ttk.Label(left, text="Shot 列表").pack(anchor="w")
        self.shot_list = tk.Listbox(left, width=24, exportselection=False)
        self.shot_list.pack(fill="both", expand=True)
        self.shot_list.bind("<<ListboxSelect>>", lambda e: self.guard(self.select_shot))
        self.button(left, "新建 Shot", self.new_shot)
        right = ttk.Frame(self.stab)
        right.pack(side="left", fill="both", expand=True)
        self.sdesc = self.field(right, "Shot 简单描述 *")
        ttk.Label(right, text="角色 *").pack(anchor="w", pady=(10, 2))
        self.sc = ttk.Combobox(right, state="readonly")
        self.sc.pack(fill="x")
        self.sc.bind("<<ComboboxSelected>>", lambda e: self.guard(self.change_shot_char))
        ttk.Label(right, text="Look / State *").pack(anchor="w", pady=(10, 2))
        self.sl = ttk.Combobox(right, state="readonly")
        self.sl.pack(fill="x")
        self.sl.bind("<<ComboboxSelected>>", lambda e: self.mark_dirty())
        ttk.Label(right, text="场景（旧 Shot 可留空；Mock 视频必须选择）").pack(anchor="w", pady=(10, 2))
        self.ss = ttk.Combobox(right, state="readonly")
        self.ss.pack(fill="x")
        self.ss.bind("<<ComboboxSelected>>", lambda e: self.guard(self.change_shot_scene))
        ttk.Label(right, text="场景状态").pack(anchor="w", pady=(10, 2))
        self.sstate = ttk.Combobox(right, state="readonly")
        self.sstate.pack(fill="x")
        self.sstate.bind("<<ComboboxSelected>>", lambda e: self.mark_dirty())
        self.sreq = self.field(right, "镜头需求 *（场景、动作、景别等）")
        self.sgen = self.field(right, "生成描述 *")
        self.sexample = tk.BooleanVar()
        ttk.Checkbutton(right, text="测试 / 示例数据", variable=self.sexample,
                        command=self.mark_dirty).pack(anchor="w", pady=8)
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        self.button(bar, "保存 Shot", self.save_shot)
        self.button(bar, "生成任务（Dummy 验证）", self.generate)
        self.button(bar, "Generate Mock 视频", self.generate_mock)
        self.button(bar, "打开数据文件夹", lambda: os.startfile(self.store.root))
        ttk.Label(right, text="Dummy 仅验证数据；Mock 视频结果到 Review 页面审核").pack(anchor="w", pady=(14, 5))
        self.result = tk.Text(right, height=8, wrap="word", state="disabled")
        self.result.pack(fill="both", expand=True)

    def refresh(self):
        selected_char = self.chars[self.sc.current()].id if hasattr(self, 'chars') and self.sc.current() >= 0 else None
        selected_scene = self.scenes[self.ss.current()].id if hasattr(self, 'scenes') and self.ss.current() >= 0 else None
        self.chars = self.store.characters()
        self.scenes = self.store.scenes()
        self.shots = self.store.shots()
        self.char_list.delete(0, "end")
        self.shot_list.delete(0, "end")
        for c in self.chars:
            self.char_list.insert("end", ("[示例] " if c.is_example else "") + c.name)
        for s in self.shots:
            self.shot_list.insert("end", ("[示例] " if s.is_example else "") + s.description)
        self.sc["values"] = [f"{i+1}. {c.name}" for i, c in enumerate(self.chars)]
        self.ss["values"] = [f"{i+1}. {s.name}" for i, s in enumerate(self.scenes)]
        if selected_char:
            self.sc.current(next(i for i, c in enumerate(self.chars) if c.id == selected_char))
        if selected_scene:
            self.ss.current(next(i for i, s in enumerate(self.scenes) if s.id == selected_scene))
        self.scene_editor.refresh()

    def new_char(self):
        if not self.confirm_discard(): return
        self.char = None
        for v in [self.cname, self.cdesc, self.cidentity]: v.set("")
        self.cexample.set(False)
        self.clear_look()
        self.render_assets()
        self.dirty = False

    def select_char(self):
        sel = self.char_list.curselection()
        if not sel or not self.confirm_discard(): return
        self.char = self.store.character(self.chars[sel[0]].id)
        self.cname.set(self.char.name)
        self.cdesc.set(self.char.description)
        self.cidentity.set(self.char.identity)
        self.cexample.set(self.char.is_example)
        self.clear_look()
        self.render_assets()
        self.dirty = False

    def read_char(self):
        payload = self.char.model_dump() if self.char else {}
        payload.update(name=self.cname.get(), description=self.cdesc.get(),
                       identity=self.cidentity.get(), is_example=self.cexample.get())
        return Character.model_validate(payload)

    def commit_look(self, char):
        if not self.lname.get().strip():
            if self.look_id or self.ldesc.get().strip() or self.lappearance.get().strip():
                raise ValueError("Look 名称不能为空")
            return
        values = dict(name=self.lname.get(), description=self.ldesc.get(),
                      appearance=self.lappearance.get(),
                      reference_ids=[char.references[i].id for i in self.look_refs.curselection()])
        if self.look_id: values["id"] = self.look_id
        look = Look(**values)
        char.looks = [look if x.id == look.id else x for x in char.looks]
        if not any(x.id == look.id for x in char.looks): char.looks.append(look)
        self.look_id = look.id

    def save_char(self):
        char = self.read_char()
        self.commit_look(char)
        self.store.save_character(char)
        self.char = char
        self.refresh()
        self.render_assets()
        self.dirty = False
        self.status.set("角色与 Look 已保存")

    def render_assets(self):
        self.ref_list.delete(0, "end")
        self.look_refs.delete(0, "end")
        self.preview_label.configure(image="", text="图片预览")
        self.preview_image = None
        if not self.char:
            self.look_choice["values"] = []
            return
        current = next((x for x in self.char.looks if x.id == self.look_id), None)
        for i, r in enumerate(self.char.references):
            self.ref_list.insert("end", ("[身份] " if r.id in self.char.identity_reference_ids else "") + r.name)
            self.look_refs.insert("end", r.name)
            if current and r.id in current.reference_ids: self.look_refs.selection_set(i)
        self.look_choice["values"] = [f"{i+1}. {x.name}" for i, x in enumerate(self.char.looks)]
        if current: self.look_choice.current(self.char.looks.index(current))

    def add_ref(self):
        filenames = filedialog.askopenfilenames(parent=self, title="添加本地 Reference 图片",
                      filetypes=[("图片", "*.png *.jpg *.jpeg *.webp")])
        if not filenames: return
        self.save_char()
        for filename in filenames:
            ref = self.store.import_reference(filename)
            if not any(x.sha256 == ref.sha256 for x in self.char.references):
                self.char.references.append(ref)
        self.store.save_character(self.char)
        self.render_assets()
        self.status.set("Reference 已复制到项目并保存；请选择身份图或关联到 Look")

    def selected_ref(self):
        sel = self.ref_list.curselection()
        if not self.char or not sel: raise ValueError("请先选择一张 Reference")
        return self.char.references[sel[0]]

    def preview(self):
        if not self.ref_list.curselection(): return
        ref = self.selected_ref()
        with Image.open(self.store.path(ref.path)) as im:
            thumb = ImageOps.exif_transpose(im)
            thumb.thumbnail((100, 60))
            self.preview_image = ImageTk.PhotoImage(thumb.copy())
        self.preview_label.configure(image=self.preview_image, text="")

    def toggle_identity(self):
        ref = self.selected_ref()
        self.save_char()
        ids = self.char.identity_reference_ids
        ids.remove(ref.id) if ref.id in ids else ids.append(ref.id)
        self.store.save_character(self.char)
        self.render_assets()
        self.status.set("身份参考图关系已保存")

    def remove_ref(self):
        ref = self.selected_ref()
        if not messagebox.askyesno("删除 Reference 关联", "从角色及其 Look 移除此图？已有任务快照与图片文件保留。", parent=self): return
        self.save_char()
        self.char.references = [x for x in self.char.references if x.id != ref.id]
        self.char.identity_reference_ids = [x for x in self.char.identity_reference_ids if x != ref.id]
        for look in self.char.looks:
            look.reference_ids = [x for x in look.reference_ids if x != ref.id]
        self.store.save_character(self.char)
        self.render_assets()
        self.status.set("Reference 关联已删除；历史任务引用的媒体仍保留")

    def clear_look(self):
        self.look_id = None
        self.look_choice.set("")
        for v in [self.lname, self.ldesc, self.lappearance]: v.set("")
        self.look_refs.selection_clear(0, "end")

    def new_look(self):
        self.save_char()
        self.clear_look()
        self.status.set("填写新 Look 后，点击保存 Look 和角色")

    def select_look(self):
        idx = self.look_choice.current()
        if not self.char or idx < 0: return
        if not self.confirm_discard():
            self.render_assets()
            return
        look = self.char.looks[idx]
        self.look_id = look.id
        self.lname.set(look.name)
        self.ldesc.set(look.description)
        self.lappearance.set(look.appearance)
        self.render_assets()
        self.dirty = False

    def save_look(self):
        if not self.lname.get().strip(): raise ValueError("请输入 Look 名称")
        self.save_char()

    def change_shot_char(self):
        idx = self.sc.current()
        self.shot_char = self.store.character(self.chars[idx].id) if idx >= 0 else None
        self.sl["values"] = [f"{i+1}. {x.name}" for i, x in enumerate(self.shot_char.looks)] if self.shot_char else []
        self.sl.set("")
        self.mark_dirty()

    def change_shot_scene(self):
        idx = self.ss.current()
        self.shot_scene = self.store.scene(self.scenes[idx].id) if idx >= 0 else None
        self.sstate['values'] = [f"{i+1}. {s.name}" for i, s in enumerate(self.shot_scene.states)] if self.shot_scene else []
        self.sstate.set("")
        self.mark_dirty()

    def new_shot(self):
        if not self.confirm_discard(): return
        self.refresh()
        self.shot = None
        for v in [self.sdesc, self.sreq, self.sgen]: v.set("")
        self.sc.set("")
        self.sl.set("")
        self.sl["values"] = []
        self.ss.set("")
        self.sstate.set("")
        self.sstate['values'] = []
        self.sexample.set(False)
        self.show_result("")
        self.dirty = False

    def select_shot(self):
        sel = self.shot_list.curselection()
        if not sel or not self.confirm_discard(): return
        self.shot = self.shots[sel[0]]
        self.sdesc.set(self.shot.description)
        self.sreq.set(self.shot.requirements)
        self.sgen.set(self.shot.generation_description)
        self.sexample.set(self.shot.is_example)
        self.sc.current(next(i for i, c in enumerate(self.chars) if c.id == self.shot.character_id))
        self.change_shot_char()
        self.sl.current(next(i for i, x in enumerate(self.shot_char.looks) if x.id == self.shot.look_id))
        self.ss.set("")
        self.sstate.set("")
        self.sstate['values'] = []
        if self.shot.scene_id:
            self.ss.current(next(i for i, s in enumerate(self.scenes) if s.id == self.shot.scene_id))
            self.change_shot_scene()
            self.sstate.current(next(i for i, s in enumerate(self.shot_scene.states) if s.id == self.shot.scene_state_id))
        self.show_result("")
        self.dirty = False

    def save_shot(self):
        if self.sc.current() < 0 or self.sl.current() < 0: raise ValueError("请选择角色和 Look")
        char = self.store.character(self.chars[self.sc.current()].id)
        # Resolve by the displayed list's stable ID, not by a potentially stale index.
        look_id = self.shot_char.looks[self.sl.current()].id
        payload = dict(description=self.sdesc.get(), character_id=char.id, look_id=look_id,
                       requirements=self.sreq.get(), generation_description=self.sgen.get(),
                       is_example=self.sexample.get())
        if self.shot: payload["id"] = self.shot.id
        if self.ss.current() >= 0:
            if self.sstate.current() < 0: raise ValueError("请选择场景状态")
            payload.update(schema_version="0.2", scene_id=self.scenes[self.ss.current()].id,
                           scene_state_id=self.shot_scene.states[self.sstate.current()].id)
        elif not self.shot or self.shot.schema_version == "0.2":
            raise ValueError("新 Shot 必须选择场景与状态；已有 A-01 Shot 仍可原样保存")
        shot = Shot(**payload)
        self.store.save_shot(shot)
        self.shot = shot
        self.refresh()
        self.dirty = False
        self.status.set("Shot 已保存；复用角色与 Look 引用")

    def show_result(self, text):
        self.result.configure(state="normal")
        self.result.delete("1.0", "end")
        self.result.insert("1.0", text)
        self.result.configure(state="disabled")

    def generate(self):
        self.save_shot()
        task, folder = self.store.generate(self.shot.id, DummyProviderAdapter())
        self.show_result("成功：统一任务与 Dummy 模拟请求已保存。\n未调用 API，未生成视频。\n"
                         + str(folder) + "\n\n" + json.dumps(task.model_dump(), ensure_ascii=False, indent=2))
        self.status.set(f"任务验证成功 · {task.character.name} / {task.look.name} · {len(task.references)} 张参考图")

    def generate_mock(self):
        self.save_shot()
        job = self.provider.submit(self.shot.id)
        self.review_panel.refresh(shot_id=self.shot.id, job_id=job.id)
        self.tabs.select(self.review_panel)
        self.status.set(f"Mock 已提交 · Take {job.take_number} · pending · 零 API 调用")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")
    args = parser.parse_args()
    app = App(args.data_dir)
    app.mainloop()


if __name__ == "__main__":
    main()
