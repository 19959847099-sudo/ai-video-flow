import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk


class ReviewPanel(ttk.Frame):
    def __init__(self, notebook, host):
        super().__init__(notebook, padding=12)
        self.host = host
        self.provider = host.provider
        self.shot_id = None
        self.items = []
        self.jobs = []
        self.job_id = None
        ttk.Label(self, text="结果审核 · Mock / fal Fixture 占位视频 · 最终 Take 由你选择").pack(anchor="w")
        self.shot_choice = ttk.Combobox(self, state="readonly")
        self.shot_choice.pack(fill="x", pady=8)
        self.shot_choice.bind("<<ComboboxSelected>>", lambda e: host.guard(self.choose_shot))
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body)
        left.pack(side="left", fill="y", padx=(0, 14))
        ttk.Label(left, text="生成执行 / Take（★ 为 Selected）").pack(anchor="w")
        self.list = tk.Listbox(left, width=33, exportselection=False)
        self.list.pack(fill="both", expand=True)
        self.list.bind("<<ListboxSelect>>", lambda e: host.guard(self.choose_job))
        right = ttk.Frame(body)
        right.pack(side="left", fill="both", expand=True)
        self.summary = tk.StringVar(value="从 Shot 页面生成视频后，在这里播放并决定。")
        ttk.Label(right, textvariable=self.summary, wraplength=760).pack(fill="x", pady=5)
        self.preview = ttk.Label(right, text="视频缩略图")
        self.preview.pack(anchor="w", pady=5)
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        host.button(bar, "播放结果", self.play)
        host.button(bar, "Select 此 Take", self.select)
        self.reason = host.field(right, "Reject 原因（可选）")
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        host.button(bar, "Reject 此 Take", self.reject)
        self.retry_prompt = host.field(right, "Retry 生成描述（可选；留空使用当前 Shot 描述）")
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        host.button(bar, "Retry 已 Reject 的 Take", self.retry)
        ttk.Label(right, text="当次生成上下文 / 最终描述（从保存的任务快照读取）").pack(anchor="w", pady=8)
        self.details = tk.Text(right, height=10, wrap="word", state="disabled")
        self.details.pack(fill="both", expand=True)

    def refresh(self, shot_id=None, job_id=None):
        self.items = self.host.store.shots()
        self.shot_choice['values'] = [f"{i+1}. {s.description}" for i, s in enumerate(self.items)]
        if shot_id is not None: self.shot_id = shot_id
        if job_id is not None: self.job_id = job_id
        if not self.shot_id: return
        idx = next((i for i, s in enumerate(self.items) if s.id == self.shot_id), None)
        if idx is None: return
        self.shot_choice.current(idx)
        self.jobs = self.provider.executions(self.shot_id)
        review = self.provider.review(self.shot_id)
        self.list.delete(0, "end")
        for job in self.jobs:
            state = job.status
            if job.result_id == review.selected_result_id and job.result_id: state = "★ Selected"
            elif job.result_id in review.rejected: state = "Rejected"
            self.list.insert("end", f"Take {job.take_number} · {state}")
        idx = next((i for i, j in enumerate(self.jobs) if j.id == self.job_id), None)
        if idx is None and self.jobs:
            idx = len(self.jobs) - 1
            self.job_id = self.jobs[idx].id
        if idx is not None:
            self.list.selection_set(idx)
            self.show_job()
        else:
            self.summary.set("尚无生成结果")
            self.preview.configure(image="", text="视频缩略图")
            self.set_details("")

    def choose_shot(self):
        if self.shot_choice.current() < 0: return
        if not self.host.confirm_discard():
            self.refresh()
            return
        self.shot_id = self.items[self.shot_choice.current()].id
        self.job_id = None
        self.reason.set("")
        self.retry_prompt.set("")
        self.host.dirty = False
        self.refresh()

    def choose_job(self):
        selected = self.list.curselection()
        if not selected: return
        self.job_id = self.jobs[selected[0]].id
        self.show_job()

    def set_details(self, text):
        self.details.configure(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", text)
        self.details.configure(state="disabled")

    def show_job(self):
        job = self.provider.execution(self.job_id)
        self.summary.set(f"Take {job.take_number} · {job.status} · " + " → ".join(job.history))
        if job.status != "completed":
            self.preview.configure(image="", text="等待模拟视频" if job.status != "failed" else "生成失败")
            self.set_details(job.error or "尚未选择最终 Take。生成在本地进行，无付费 API 调用。")
            return
        result, task = self.provider.trace(job.result_id)
        with Image.open(self.host.store.path(result.poster_path)) as image:
            thumb = image.copy()
            thumb.thumbnail((480, 230))
            self.photo = ImageTk.PhotoImage(thumb)
        self.preview.configure(image=self.photo, text="")
        review = self.provider.review(self.shot_id)
        decision = "Selected" if review.selected_result_id == result.id else (
            "Rejected：" + review.rejected[result.id] if result.id in review.rejected else "待人工决定")
        self.summary.set(f"Take {job.take_number} · {decision} · {result.duration:g} 秒 · {result.provider}")
        text = (f"Shot：{task.shot.description}\n角色：{task.character.name} / {task.look.name}\n"
                f"场景：{task.scene.name} / {task.scene_state.name}\n"
                f"角色参考图：{', '.join(r.name for r in task.references)}\n"
                f"场景参考图：{', '.join(r.name for r in task.scene_references)}\n"
                f"Task：{task.id}\n素材：{result.path}\n\n{self.provider.submitted_prompt(task.id)}")
        if job.provider == "fal":
            import json
            exchange = json.loads(self.host.store.path(f"tasks/{task.id}/provider_exchange.json").read_text(encoding="utf-8"))
            text += f"\n\nfal request_id：{exchange.get('request_id', '')}\n模型：{job.model}\nTransport：Fixture，本地模拟，真实 API 调用为 0"
        self.set_details(text)

    def current_result(self):
        if not self.job_id: raise ValueError("请选择一个已完成的 Take")
        job = self.provider.execution(self.job_id)
        if job.status != "completed" or job.shot_id != self.shot_id:
            raise ValueError("请选择当前 Shot 已完成的 Take")
        return job.result_id

    def play(self):
        process = self.provider.play(self.current_result())
        self.host.players.append(process)
        self.host.status.set("已打开 FFplay 播放实际 MP4；播放完自动关闭")

    def select(self):
        self.provider.select(self.shot_id, self.current_result())
        self.refresh()
        self.host.status.set("Selected Take 已明确保存，重启后保持")

    def reject(self):
        self.provider.reject(self.shot_id, self.current_result(), self.reason.get())
        self.host.dirty = bool(self.retry_prompt.get().strip())
        self.refresh()
        self.host.status.set("已 Reject 并保存原因；可调整生成描述后 Retry")

    def retry(self):
        job = self.provider.submit(self.shot_id, retry_of=self.current_result(),
                                   generation_description=self.retry_prompt.get().strip() or None)
        self.reason.set("")
        self.retry_prompt.set("")
        self.host.dirty = False
        self.refresh(job_id=job.id)
        self.host.status.set(f"Retry 已提交 · Take {job.take_number} · pending · 使用新的任务快照")
