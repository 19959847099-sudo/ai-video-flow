"""Scene-specific editor; shares the existing Store image import and persistence."""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageOps, ImageTk
from .core import Scene, SceneState


class SceneEditor(ttk.Frame):
    def __init__(self, notebook, host):
        super().__init__(notebook, padding=12)
        self.host = host
        self.store = host.store
        self.scene = None
        self.state_id = None
        self.items = []
        left = ttk.Frame(self)
        left.pack(side="left", fill="y", padx=(0, 14))
        ttk.Label(left, text="场景列表").pack(anchor="w")
        self.list = tk.Listbox(left, width=24, exportselection=False)
        self.list.pack(fill="both", expand=True)
        self.list.bind("<<ListboxSelect>>", lambda e: host.guard(self.choose))
        host.button(left, "新建场景", self.new)
        right = ttk.Frame(self)
        right.pack(side="left", fill="both", expand=True)
        self.name = host.field(right, "场景名称 *")
        self.description = host.field(right, "简短场景描述")
        self.identity = host.field(right, "稳定视觉 / 空间特征 *")
        self.example = tk.BooleanVar()
        ttk.Checkbutton(right, text="测试 / 示例数据", variable=self.example,
                        command=host.mark_dirty).pack(anchor="w", pady=4)
        box = ttk.LabelFrame(right, text="场景 Reference · 稳定图用于全部状态", padding=8)
        box.pack(fill="x", pady=6)
        self.refs = tk.Listbox(box, height=4, exportselection=False)
        self.refs.pack(side="left", fill="x", expand=True)
        self.refs.bind("<<ListboxSelect>>", lambda e: host.guard(self.preview))
        self.picture = ttk.Label(box, text="图片预览", width=20)
        self.picture.pack(side="right", padx=8)
        bar = ttk.Frame(right)
        bar.pack(fill="x")
        host.button(bar, "添加场景图片…", self.add_refs)
        host.button(bar, "删除图片关联", self.remove_ref)
        host.button(bar, "设为 / 取消稳定图", self.toggle_identity)
        box = ttk.LabelFrame(right, text="场景 State / Variant", padding=8)
        box.pack(fill="both", expand=True, pady=6)
        self.choice = ttk.Combobox(box, state="readonly")
        self.choice.pack(fill="x")
        self.choice.bind("<<ComboboxSelected>>", lambda e: host.guard(self.choose_state))
        self.state_name = host.field(box, "状态名称 *")
        self.state_description = host.field(box, "状态描述")
        self.environment = host.field(box, "环境变化（光线、天气等）")
        ttk.Label(box, text="当前状态专用图（点击多选）").pack(anchor="w", pady=(6, 0))
        self.state_refs = tk.Listbox(box, height=3, selectmode="multiple", exportselection=False)
        self.state_refs.pack(fill="x")
        self.state_refs.bind("<<ListboxSelect>>", lambda e: host.mark_dirty())
        bar = ttk.Frame(box)
        bar.pack(fill="x")
        host.button(bar, "新建场景状态", self.new_state)
        host.button(bar, "保存状态与场景", self.save_state)
        host.button(right, "保存场景", self.save)

    def refresh(self):
        self.items = self.store.scenes()
        self.list.delete(0, "end")
        for s in self.items:
            self.list.insert("end", ("[示例] " if s.is_example else "") + s.name)

    def new(self):
        if not self.host.confirm_discard(): return
        self.scene = None
        for v in [self.name, self.description, self.identity]: v.set("")
        self.example.set(False)
        self.clear_state()
        self.render()
        self.host.dirty = False

    def choose(self):
        sel = self.list.curselection()
        if not sel or not self.host.confirm_discard(): return
        self.scene = self.store.scene(self.items[sel[0]].id)
        self.name.set(self.scene.name)
        self.description.set(self.scene.description)
        self.identity.set(self.scene.identity)
        self.example.set(self.scene.is_example)
        self.clear_state()
        self.render()
        self.host.dirty = False

    def save(self):
        payload = self.scene.model_dump() if self.scene else {}
        payload.update(name=self.name.get(), description=self.description.get(),
                       identity=self.identity.get(), is_example=self.example.get())
        scene = Scene.model_validate(payload)
        if self.state_name.get().strip():
            values = dict(name=self.state_name.get(), description=self.state_description.get(),
                          environment=self.environment.get(),
                          reference_ids=[scene.references[i].id for i in self.state_refs.curselection()])
            if self.state_id: values['id'] = self.state_id
            state = SceneState(**values)
            scene.states = [state if x.id == state.id else x for x in scene.states]
            if not any(x.id == state.id for x in scene.states): scene.states.append(state)
            self.state_id = state.id
        elif self.state_id or self.state_description.get().strip() or self.environment.get().strip():
            raise ValueError("场景状态名称不能为空")
        self.store.save_scene(scene)
        self.scene = scene
        self.host.refresh()
        self.render()
        self.host.dirty = False
        self.host.status.set("场景与状态已保存")

    def render(self):
        self.refs.delete(0, "end")
        self.state_refs.delete(0, "end")
        self.picture.configure(image="", text="图片预览")
        self.photo = None
        self.choice['values'] = []
        if not self.scene: return
        state = next((s for s in self.scene.states if s.id == self.state_id), None)
        for i, ref in enumerate(self.scene.references):
            self.refs.insert("end", ("[稳定] " if ref.id in self.scene.identity_reference_ids else "") + ref.name)
            self.state_refs.insert("end", ref.name)
            if state and ref.id in state.reference_ids: self.state_refs.selection_set(i)
        self.choice['values'] = [f"{i+1}. {s.name}" for i, s in enumerate(self.scene.states)]
        if state: self.choice.current(self.scene.states.index(state))

    def add_refs(self):
        paths = filedialog.askopenfilenames(parent=self, title="添加场景 Reference 图片",
                    filetypes=[("图片", "*.png *.jpg *.jpeg *.webp")])
        if not paths: return
        self.save()
        for path in paths:
            ref = self.store.import_reference(path)
            if not any(r.sha256 == ref.sha256 for r in self.scene.references): self.scene.references.append(ref)
        self.store.save_scene(self.scene)
        self.render()
        self.host.status.set("场景图片已导入并保存；请选择稳定图或关联到状态")

    def selected_ref(self):
        sel = self.refs.curselection()
        if not self.scene or not sel: raise ValueError("请先选择场景图片")
        return self.scene.references[sel[0]]

    def preview(self):
        if not self.refs.curselection(): return
        ref = self.selected_ref()
        with Image.open(self.store.path(ref.path)) as image:
            thumb = ImageOps.exif_transpose(image)
            thumb.thumbnail((100, 60))
            self.photo = ImageTk.PhotoImage(thumb.copy())
        self.picture.configure(image=self.photo, text="")

    def toggle_identity(self):
        ref = self.selected_ref()
        self.save()
        ids = self.scene.identity_reference_ids
        ids.remove(ref.id) if ref.id in ids else ids.append(ref.id)
        self.store.save_scene(self.scene)
        self.render()

    def remove_ref(self):
        ref = self.selected_ref()
        if not messagebox.askyesno("移除场景图片关联", "移除此场景及状态的图片关联？历史任务与原文件保留。", parent=self): return
        self.save()
        self.scene.references = [r for r in self.scene.references if r.id != ref.id]
        self.scene.identity_reference_ids = [i for i in self.scene.identity_reference_ids if i != ref.id]
        for state in self.scene.states: state.reference_ids = [i for i in state.reference_ids if i != ref.id]
        self.store.save_scene(self.scene)
        self.render()

    def clear_state(self):
        self.state_id = None
        self.choice.set("")
        for v in [self.state_name, self.state_description, self.environment]: v.set("")
        self.state_refs.selection_clear(0, "end")

    def new_state(self):
        self.save()
        self.clear_state()

    def choose_state(self):
        idx = self.choice.current()
        if not self.scene or idx < 0: return
        if not self.host.confirm_discard():
            self.render()
            return
        state = self.scene.states[idx]
        self.state_id = state.id
        self.state_name.set(state.name)
        self.state_description.set(state.description)
        self.environment.set(state.environment)
        self.render()
        self.host.dirty = False

    def save_state(self):
        if not self.state_name.get().strip(): raise ValueError("请输入场景状态名称")
        self.save()
