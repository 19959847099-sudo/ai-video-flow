# AI 视频个人生产工作流 · A-04

本地桌面主链：角色 + 场景 → Shot → Generation Task → Mock / fal Fixture 视频 → Review → Select / Reject / Retry。

## 安装与启动

使用带 Tkinter 的 Python 3.11+，以及 PATH 中的 FFmpeg（含 ffmpeg、ffprobe、ffplay）。本机已具备所需工具，已验证 Python 3.13.3、Pillow 12.1.1、Pydantic 2.12.5 和 FFmpeg 8.1。

在项目目录执行：

```powershell
python -m pip install -r requirements.txt
python -m app.gui
```

也可双击 `start.cmd`。启动方式与 A-01 相同。应用不需要网络或 API 密钥，不调用付费服务。一次只打开一个窗口编辑同一数据目录。

## 角色与场景

1. **角色卡**：新建角色，填写名称、核心身份，保存；导入本地图片。选图可预览，“设为 / 取消身份图”用于所有 Look。
2. 填写 Look 名称、描述、外观，在下方列表点击选择专用参考图，点“保存 Look 和角色”。用“新建 Look”增加另一套造型，下拉选择已有 Look 可编辑。
3. **场景**：新建场景，填写名称、稳定视觉 / 空间特征；导入图片。“设为 / 取消稳定图”指定所有状态共用的场景参考图。
4. 填写场景状态、环境变化，点击选择状态专用图片，保存。用“新建场景状态”增加白天 / 雨夜等变体。

PNG、JPEG、WebP 图片由同一套导入逻辑复制到项目内，以内容 SHA-256 去重。删除 Reference 只移除该资产与其 Look / State 关联；不删除历史任务可能使用的媒体。每次任务只使用稳定图与当前 Look / State 图的并集，不混入其他状态专用图。

## Shot、生成与审核

1. **Shot / 生成任务**：新建 Shot，选择角色、Look、场景、场景状态，填写镜头需求和生成描述，保存。
2. 选择生成方式：**本地 Mock** 或 **fal / Kling O3 · Fixture（零调用）**，然后点 **生成视频（零调用）**。提交任务后进入 Review。界面显示 pending / processing / completed，本地 FFmpeg 生成 3 秒 H.264 MP4，并自动关联回 Shot。应用后台处理媒体，界面仍可操作。
3. **结果 / Review**：选择 Shot 和 Take，可查看实际视频缩略图与当次上下文；点“播放结果”用 FFplay 播放 MP4，播放结束自动关闭，也可用 Esc 退出。
4. 点 **Select 此 Take** 保存明确选择，列表用 ★ 标识。系统不会自动选择最新结果。
5. 不满意时填写可选原因，点 **Reject 此 Take**。随后可填写“Retry 生成描述”，再点 **Retry 已 Reject 的 Take**，产生新的 Task 与新 Take。
6. Retry 描述只作用于这次新任务，不覆盖 Shot 的默认生成描述；留空使用当前已保存的 Shot 描述。上下文使用提交时的角色、场景快照。
7. 每个 Shot 一次允许一个进行中的生成。失败会保留错误和生成次数；解决工具问题后可回 Shot 页重新 Generate。

编辑后先保存再切换页。退出会等待正在处理的短媒体操作收尾；若进程意外中断，已持久化的 pending / processing 任务会在下次启动继续处理。Select、Reject 与 Retry 原因都会持久化。

## A-01 兼容

A-01 的角色、Look、Reference、两个旧 Shot 和四份历史任务保留。旧 Shot 没有场景时仍可读取、编辑并执行 **生成任务（Dummy 验证）**，不会被自动补造场景或批量重写。

要让旧 Shot 生成 Mock 视频，在 GUI 中为它选择场景和状态并保存即可。新 Shot 必须具备双资产引用。旧 0.1 任务照常读取；新双资产任务标为 0.2。历史任务 JSON 不随资产编辑更新。

## 文件与追溯

```text
app/core.py          Character / Scene / Shot / Task 与共用文件存储
app/gui.py           主窗口与角色、Shot 操作
app/scene_gui.py     场景编辑
app/production.py    Mock 生命周期、媒体入库与 Review 记录
app/fal_adapter.py   fal 契约映射、本地 Fixture 与两条明确执行路线
app/fixtures/        按官方契约构造的响应样本
app/review_gui.py    视频预览、人工 Select / Reject / Retry
schemas/             从 Pydantic 导出的 JSON Schema

data/characters/    Character JSON，内含 Look 与 Reference 关系
data/scenes/        Scene JSON，内含 State 与 Reference 关系
data/shots/         稳定 ID 引用双资产，保留旧 Shot 兼容
data/assets/        内容哈希命名的参考图
data/tasks/<id>/    不变的 task.json，以及独立 Provider 请求
data/executions/    执行 ID、状态、Take 编号、结果关联、retry_of
data/results/<id>/  video.mp4、poster.png、result.json
data/reviews/       每个 Shot 的 selected_result_id 与 Reject 原因
data/mock_outputs/  生成期间临时中间文件，成功后清理
```

Selected Take → Result → Execution / Task → 最终 Prompt、Shot 快照、Character / Look、Scene / State，可以完整追溯。Provider 名称位于执行和结果记录，核心角色、场景与任务不绑定 Provider。`prepare(task, asset_root)` 边界保留，Mock 另实现 submit / poll。

备份和迁移请复制整个 `data/`；其中媒体路径均相对于该目录。可用 `python -m app.gui --data-dir <目录>` 打开其他数据目录，正常操作不需要手写路径。原导入图片可移走，不影响已复制资产。

## 验证与证据

```powershell
python -m unittest discover -s tests -v
python tools/verify_a03.py
```

第二条是本轮已交付示例数据的验收核验，不是约束用户今后的生产数据必须保持不变。当前保留 1 个角色、2 个 Look、1 个场景、2 个 State、6 张参考图，以及 2 个 A-01 旧 Shot、2 个 A-02 示例 Shot 和 2 个 A-03 示例 Shot。

`evidence/A-02/` 保存实际桌面截图、操作记录、视频核验、历史快照与冻结文件哈希。`A-01-before.zip` 是施工前代码、Schema、测试及数据备份；不是运行依赖。原 `tools/verify_delivery.py` 是 A-01 当时的固定示例验收脚本，当前使用上面的 A-03 入口。

`tools/run_a03_probe.py` / `tools/drive_a03.py` 是本轮测试辅助（A-02 工具也保留）：只读控件位置后驱动真实桌面鼠标、键盘及文件选择器，不替代业务逻辑。它们使用隔离的 `.test-tools/pywinauto`，不属于应用运行依赖。用户启动时不需要这些工具。

## 当前边界

视频是明确标注 MOCK / 测试的占位卡片，不是真实 AI 作品；Select / Reject 演示也仅针对测试素材，不是审美结论。没有真实收费 API、自动审美、数据库、云服务、第三类资产、剪辑器或完整 Attempt Ledger。角色与场景一致性尚未经过真实模型验证，阶段 A 尚未完成。A-04 已增加可选 DSH 外部执行入口，见下文。

本轮直接复用本机 FFmpeg CLI 做编码、探测、缩略图与播放；Python 只组织数据与流程。没有新增 Python 运行依赖，也没有复制 FFmpeg 二进制到项目；迁移机器需安装对应工具。


## A-03：fal 官方契约的零调用接入

首个 Provider 为 fal.ai，模型为 Kling O3 Standard Reference-to-Video。角色与场景参考图映射为 image_urls 和 @Image 引用，实际最终描述保存于任务目录的 provider_request.json。Review 可读取该描述及模拟 request_id；核心 GenerationTask 保持 Provider-independent。

目前只有本地 Fixture Transport。没有 HTTP 客户端、API Key 读取或真实调用开关；即使环境中有密钥，也不会使用。Fixture 是按官方契约构造的样本响应，不是线上录制；占位视频使用 FFmpeg 生成，不能作为 Kling 画质或连续性证明。详细契约与边界见 [A-03 Provider 契约](evidence/A-03/provider-contract.md)。

每次 fal 生成经过提交响应、IN_QUEUE、IN_PROGRESS、COMPLETED、视频回收；响应保存在 provider_exchange.json。COMPLETED 带错误时判为失败。错误与缺失媒体不会自动 Select，也不自动重新提交。Retry 沿用被 Reject 结果的 Provider。

当前 fal V0 限制：最多 4 张有效参考图、单图 10 MB、最终描述 2500 字符；固定 3 秒、16:9、无音频。这是本轮适配预算。超限会明确报错，不会偷偷省略生产输入。

新增 GUI 验收示例：白天镜头使用 fal Fixture 生成两条 Take，第一条 Reject，第二条 Selected；雨夜镜头复用角色与场景、切换 Look / State，用于回归本地 Mock。所有这些都是测试数据。

验证：`python -m unittest discover -s tests -v`；交付数据检查：`python tools/verify_a03.py`。A-01 / A-02 的固定示例验收脚本和历史回执保留，当前新增数据请使用 A-03 检查脚本。正式启动仍为 `python -m app.gui` 或 `start.cmd`。

正式回执：[A-03 施工回执](evidence/A-03/A-03施工回执.md)。

## A-04：DSH 外部编排与能力证明

官方 DeepSeek Harness 0.1.5-rc.2 通过四个生产工具读取已有 Shot、构建任务、执行 fal Fixture、调用 ffprobe 并回读结果。使用无密钥、确定顺序的工具编排，没有调用 DeepSeek 模型，也不代表已验证自主 Agent 规划。

关闭正在编辑同一数据目录的 GUI，在根目录执行：

```powershell
python tools/run_harness.py da107ac03bf949c0a099b4159fea8701
```

每次执行会新建一个候选 Take，DSH 完成后退出。再用原 GUI 进行播放及人工审核；窗口标题保留 A-03，因为本轮未修改 GUI 代码。数据不依赖 DSH 进程或 trace，原启动方式与 Python 依赖不变。不要同时运行多个写入者。

外部运行时安装、四个工具语义和版本约束见 [DSH 接入说明](integrations/dsh/README.md)。当前交付核验入口为 `python tools/verify_a04.py`；完整自动测试仍为 `python -m unittest discover -s tests -v`。该交付核验针对本轮固定示例，后续人工选择或编辑数据后不要求继续保持这一基线。

本轮实际运行新增一条雨夜 fal Fixture 候选视频，未自动 Select。模型与视频 API 调用均为 0。ComfyUI、WhisperX、OTIO 未接入。

交付：[A-04 施工回执](evidence/A-04/A-04施工回执.md)、[架构](evidence/A-04/architecture.md)、[开源集成图](evidence/A-04/open-source-integration-map.md)、[能力证明与简历候选](evidence/A-04/resume-evidence.md)。
