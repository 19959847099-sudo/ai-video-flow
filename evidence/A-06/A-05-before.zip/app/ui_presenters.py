"""Read-only UI projections. No extra persistent status machine."""
import json
from pathlib import Path


def take_state(job, review):
    if job.result_id and job.result_id == review.selected_result_id: return 'SELECTED', 'selected'
    if job.result_id and job.result_id in review.rejected: return 'REJECTED', 'rejected'
    return {'completed':('待审核', 'ready'), 'pending':('排队中', 'pending'),
            'processing':('生成中', 'pending'), 'failed':('执行失败', 'failed')}[job.status]


def shot_state(shot, jobs, review):
    if review.selected_result_id: return '已选定'
    if any(j.status in ('pending', 'processing') for j in jobs): return '生成中'
    if any(j.result_id and j.result_id not in review.rejected for j in jobs): return '待审核'
    if any(j.result_id in review.rejected for j in jobs): return '可重试'
    if any(j.status == 'failed' for j in jobs): return '执行失败'
    return '可生成' if shot.scene_id else '待补场景'


def mode(job):
    if not job.simulation_only: return 'REAL'
    return 'ZERO-CALL' if job.provider == 'fal' else 'MOCK'


def harness_summary(root, job):
    """Only match explicit IDs; missing sidecar never blocks production access."""
    candidates = [Path(root)/'evidence/A-04/production-run/trace.json']
    candidates += sorted((Path(root)/'evidence/A-04/runs').glob('*/trace.json'))
    for path in candidates:
        try:
            trace = json.loads(path.read_text(encoding='utf-8'))
            result = trace.get('result', {})
            if (result.get('execution_id'), result.get('task_id'), trace.get('shot_id')) != (job.id, job.task_id, job.shot_id): continue
            lines = [f"DSH {trace.get('version', '')} · 历史执行 {trace.get('status', '未知')}"]
            names = {'get_shot_context':'读取 Shot', 'build_generation_task':'构建生成任务',
                     'dry_run_generation':'Kling O3 Dry Run / 结果入库', 'inspect_media':'ffprobe 媒体探测'}
            for step in trace.get('steps', []):
                lines.append(('✓ ' if step.get('status') == 'completed' else '· ') + names.get(step.get('tool'), '工具') + ' · ' + step.get('status', '未知'))
            lines.append('这是历史记录，不表示 DSH 当前正在运行。')
            return '\n'.join(lines), str(path)
        except (OSError, ValueError, TypeError, AttributeError): continue
    return '没有匹配的 Harness 记录。此结果可独立读取和审核，无需启动 DSH。', None
