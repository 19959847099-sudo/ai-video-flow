"""Explicit ordered-shot handoff, not a timeline editor."""
import json,tkinter as tk
from tkinter import ttk
from .rough_cut import RoughCutProduction,TimelineDefinition
from .ui_widgets import Rows,readonly_text,put_text

class RoughCutPanel(ttk.Frame):
    def __init__(self,parent,host):
        super().__init__(parent,padding=12);self.host=host;self.production=RoughCutProduction(host.store);self.current=None;self.order=[];self.items=[];self.shots=[]
        ttk.Label(self,text='ROUGH CUT / FIXTURE SOURCE MEDIA / NOT FINAL MASTER',style='Heading.TLabel').pack(anchor='w')
        top=ttk.Frame(self);top.pack(fill='x',pady=8)
        self.saved=ttk.Combobox(top,state='readonly');self.saved.pack(side='left',fill='x',expand=True);self.saved.bind('<<ComboboxSelected>>',lambda e:host.guard(self.open))
        host.button(top,'新建 Timeline',self.new);host.button(top,'刷新 Timeline',self.refresh)
        self.name=host.field(self,'Timeline 名称 *')
        policy=ttk.Frame(self);policy.pack(fill='x',pady=8)
        self.allow_audio=tk.BooleanVar(value=False);self.allow_subtitles=tk.BooleanVar(value=False)
        ttk.Checkbutton(policy,text='允许缺失对白 / 无音频 Shot（静音）',variable=self.allow_audio).pack(side='left')
        ttk.Checkbutton(policy,text='允许当前音频没有字幕',variable=self.allow_subtitles).pack(side='left')
        ttk.Label(self,text='策略：视频时长驱动；对白依序排列并截短超出部分；视频原音静音；字幕单独 SRT。',style='Muted.TLabel').pack(anchor='w')
        bottom=ttk.Frame(self);bottom.pack(side='bottom',fill='x',pady=8)
        for label,method in [('保存顺序',self.save),('Validate',self.validate),('Build Timeline',self.build),('Generate Preview',self.preview),('Open Preview',self.play),('Export Handoff',self.export)]:host.button(bottom,label,method)
        content=ttk.Panedwindow(self,orient='horizontal');content.pack(fill='both',expand=True,pady=8)
        left=ttk.Frame(content);right=ttk.Frame(content);content.add(left,weight=1);content.add(right,weight=2)
        add_row=ttk.Frame(left);add_row.pack(fill='x')
        self.available=ttk.Combobox(add_row,state='readonly');self.available.pack(side='left',fill='x',expand=True);host.button(add_row,'添加 Shot',self.add)
        controls=ttk.Frame(left);controls.pack(fill='x')
        host.button(controls,'Move Up',lambda:self.move(-1));host.button(controls,'Move Down',lambda:self.move(1));host.button(controls,'移出顺序',self.remove)
        self.order_list=Rows(left,width=360);self.order_list.pack(fill='both',expand=True)
        self.details=readonly_text(right,height=15)
    def refresh(self):
        self.items=self.production.definitions();self.shots=self.host.store.shots();self.saved['values']=[x.name+' · '+x.id[:8] for x in self.items];self.available['values']=[s.description+' · '+s.id[:8] for s in self.shots]
        if self.shots:self.available.current(0)
    def new(self):
        self.refresh();self.current=None;self.order=[];self.name.set('');self.allow_audio.set(False);self.allow_subtitles.set(False);self.render();put_text(self.details,'Draft：添加 Shot，明确允许策略，再保存。')
    def open(self):
        if self.saved.current()<0:return
        self.current=self.production.definition(self.items[self.saved.current()].id);d=self.current;self.order=list(d.shot_ids);self.name.set(d.name);self.allow_audio.set(d.allow_missing_audio);self.allow_subtitles.set(d.allow_missing_subtitles);self.render();self.report()
    def render(self,selection=None):
        self.order_list.delete(0,'end')
        for i,sid in enumerate(self.order):
            s=next(s for s in self.shots if s.id==sid);selected=self.production.video.review(sid).selected_result_id
            self.order_list.insert('end',f'{i+1}. {s.description}\n{sid[:8]} · Video '+(selected[:8] if selected else 'MISSING'))
        if selection is not None:self.order_list.selection_set(selection)
    def add(self):
        if self.available.current()<0:raise ValueError('请选择 Shot')
        sid=self.shots[self.available.current()].id
        if sid in self.order:raise ValueError('Shot 已在顺序中')
        self.order.append(sid);self.render(len(self.order)-1)
    def move(self,delta):
        selected=self.order_list.curselection()
        if not selected:return
        i=selected[0];j=i+delta
        if 0<=j<len(self.order):self.order[i],self.order[j]=self.order[j],self.order[i];self.render(j)
    def remove(self):
        selected=self.order_list.curselection()
        if selected:self.order.pop(selected[0]);self.render()
    def save(self):
        d=dict(name=self.name.get(),shot_ids=self.order,allow_missing_audio=self.allow_audio.get(),allow_missing_subtitles=self.allow_subtitles.get())
        if self.current:d['id']=self.current.id
        self.current=self.production.save(TimelineDefinition(**d));self.refresh();self.host.status.set('Timeline 顺序与允许策略已保存');return self.current
    def report(self):
        m=self.production.resolve(self.current.id);lines=[m['label'],m['status'],f'Rate {m["rate"]} fps · {m["duration"]:.3f}s']
        for c in m['clips']:lines.append(f'\n{c["name"]}\nVideo {c["result_id"][:8]} · {c["metadata"]["duration"]:.3f}s\nAudio: '+(', '.join(a['result_id'][:8] for a in c['audios']) or '无')+f' · 字幕 {len(c["subtitles"])} 段')
        lines+=['\nBLOCK: '+x for x in m['errors']]+['\nWARNING: '+x for x in m['warnings']]
        try:folder,_=self.production.current(self.current.id);lines+=['\nBuild: '+folder.name,'Preview: '+str((folder/'preview.json').exists()),'Handoff: '+str((folder/'handoff.json').exists())]
        except ValueError as e:lines.append('\n'+str(e))
        put_text(self.details,'\n'.join(lines))
    def validate(self):self.save();self.report()
    def build(self):self.save();self.production.build(self.current.id);self.report();self.host.status.set('OTIO 已实际生成并回读；不是最终成片')
    def preview(self):
        if not self.current:raise ValueError('请先保存并 Build')
        self.require_saved();self.host.status.set('FFmpeg 正在装配本地 Preview');self.host.update_idletasks();self.production.preview(self.current.id);self.report();self.host.status.set('ROUGH CUT Preview 已生成')
    def require_saved(self):
        d=self.production.definition(self.current.id)
        if (d.name,d.shot_ids,d.allow_missing_audio,d.allow_missing_subtitles)!=(self.name.get(),self.order,self.allow_audio.get(),self.allow_subtitles.get()):raise ValueError('有未保存的顺序 / 策略；请先保存并重新 Build')
    def play(self):
        if not self.current:raise ValueError('请先 Build / Generate Preview')
        self.require_saved();self.host.players.append(self.production.play(self.current.id))
    def export(self):
        if not self.current:raise ValueError('请先 Build / Generate Preview')
        self.require_saved();package=self.production.export(self.current.id);self.report();self.host.status.set('Portable Handoff 已保存：'+str(package))
